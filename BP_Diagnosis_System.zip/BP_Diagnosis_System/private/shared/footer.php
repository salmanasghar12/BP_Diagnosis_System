</div>
 <footer class="footer-distributed">
<div class= "container" >
 
    &nbsp; &nbsp; <br>
    
        <h2 class="text-light">How we care for</h2>
        <h6 class="text-light">
        <p  class="text-light">
         Blood Pressure Diagnostics is an interactive portal for blood pressure Patients and Doctors where they can interact with each other.
         Patients can ask for prescription by uploading their details and also they can ask for appointment and Doctors can post prescriptions and confirm appointment and much more...... 
        </p>
      </h6>
  &nbsp; &nbsp; &nbsp; &nbsp;
  <h4>
      <p class="text-light" align="center"><i class="fa fa-envelope"></i>
        <a class="text-light" href="mailto:iamsalmanasghar@gmail.com"> Contact Us</a>
        &nbsp; &nbsp;
        <i class="text-light fa fa-phone">+92 331 4548034</i> 
        <br></p>
      </h4>
      
    
      
<div class= "copyright col-11 col-sm-8 col-md-6 mx-auto text-center">
      <p class="text-light">&copy; Copyright <?php echo date('Y'); ?>, All Rights Reserved </p>
    </div>
</div>

      </footer>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      <script type="text/javascript" src="<?php echo getScriptPath('main_script.js'); ?>"></script>
  </body>
</html>
