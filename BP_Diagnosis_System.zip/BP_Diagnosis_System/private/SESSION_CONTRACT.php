<?php

class SessionContract{
  public const SESSION_PATIENT_ID = 'patient_id';
   public const SESSION_DOCTOR_ID = 'doctor_id';
   public const SESSION_ADMIN_ID = 'admin_id';

}

 ?>
