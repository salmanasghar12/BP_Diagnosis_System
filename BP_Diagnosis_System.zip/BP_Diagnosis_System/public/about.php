<?php  require_once('../private/initialize.php');
  $page_title =  "About Us";
  require_once(getSharedFilePath('main/header.php'));
?>


<div class ="container">


&nbsp; &nbsp; &nbsp; &nbsp;
  <!-- Services -->

    <div class="container">

<h1 align="center"> About Us </h1>
<h4 align="center"> What is our Portal all about </h4>
  
 
  &nbsp; &nbsp; &nbsp; 
        <div class="card-group">

        <div class="col-lg-5 col-md-6 mx-auto card">
          <h5>Ask For Prescriptions</h5>
                <p>Patients after logging in can ask for prescription that will be posted to the Doctor and as soon as the Doctor gives a reply, Patient readily receives it in his/her dashboard. </p>
                </div>
          
        <div class="col-lg-5 col-md-6 mx-auto service_col card">
        <h5>Book Appointment</h5>
                <p>Patients can easily book appointment with any doctor he/she wants.He/She can see the Doctor's detail and select accordingly.He/She will request for appointment where Doctor can approve on his ease on any specific date and time.</p>
              </div>
            </div>
            </div>
</div>            
<?php require_once(getSharedFilePath('footer.php'));  ?>
