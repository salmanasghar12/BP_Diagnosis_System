<?php  require_once('private/initialize.php');
    redirectTo('/BP_Diagnosis_System/public/index.php');
 ?>
